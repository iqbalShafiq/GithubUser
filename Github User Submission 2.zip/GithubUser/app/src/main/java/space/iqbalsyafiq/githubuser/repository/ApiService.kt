package space.iqbalsyafiq.githubuser.repository

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query
import space.iqbalsyafiq.githubuser.constant.ApiConstant
import space.iqbalsyafiq.githubuser.model.SearchResponse
import space.iqbalsyafiq.githubuser.model.UserResponse

interface ApiService {

    @GET("search/users")
    @Headers("Authorization: ${ApiConstant.TOKEN_API}")
    fun searchUsers(
        @Query("q") username: String
    ): Call<SearchResponse>

    @GET("users")
    @Headers("Authorization: ${ApiConstant.TOKEN_API}")
    fun getListUsers(): Call<List<UserResponse>>

    @GET("users/{username}")
    @Headers("Authorization: ${ApiConstant.TOKEN_API}")
    fun getDetailUser(
        @Path("username") username: String
    ): Call<UserResponse>

    @GET("users/{username}/followers")
    @Headers("Authorization: ${ApiConstant.TOKEN_API}")
    fun getFollowers(
        @Path("username") username: String
    ): Call<List<UserResponse>>

    @GET("users/{username}/following")
    @Headers("Authorization: ${ApiConstant.TOKEN_API}")
    fun getFollowing(
        @Path("username") username: String
    ): Call<List<UserResponse>>
}