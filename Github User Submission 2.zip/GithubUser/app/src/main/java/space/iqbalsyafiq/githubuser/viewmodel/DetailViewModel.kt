package space.iqbalsyafiq.githubuser.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import space.iqbalsyafiq.githubuser.model.UserResponse
import space.iqbalsyafiq.githubuser.repository.ApiConfig

class DetailViewModel: ViewModel() {

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _isError = MutableLiveData<Boolean>()
    val isError: LiveData<Boolean> = _isError

    private val _user = MutableLiveData<UserResponse>()
    val user: LiveData<UserResponse> = _user

    fun getDetailUser(username: String) {
        _isLoading.value = true

        viewModelScope.launch(Dispatchers.IO) {
            ApiConfig.getApiService().getDetailUser(username).enqueue(object: Callback<UserResponse> {
                override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                    _isLoading.value = false

                    if (response.isSuccessful) {
                        _user.value = response.body()
                        _isError.value = false
                    } else {
                        _isError.value = true
                    }
                }

                override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                    _isLoading.value = false
                    _isError.value = true
                }
            })
        }
    }
}