package space.iqbalsyafiq.githubuser.constant

class ApiConstant {
    companion object {
        const val BASE_URL = "https://api.github.com/"
        const val TOKEN_API = "token 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"
    }
}