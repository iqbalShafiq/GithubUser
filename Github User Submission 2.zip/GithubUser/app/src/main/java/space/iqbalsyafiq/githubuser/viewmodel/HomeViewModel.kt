package space.iqbalsyafiq.githubuser.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import space.iqbalsyafiq.githubuser.model.SearchResponse
import space.iqbalsyafiq.githubuser.model.UserResponse
import space.iqbalsyafiq.githubuser.repository.ApiConfig

class HomeViewModel: ViewModel() {

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _isError = MutableLiveData<Boolean>()
    val isError: LiveData<Boolean> = _isError

    private val _users = MutableLiveData<List<UserResponse>>()
    val users: LiveData<List<UserResponse>> = _users

    fun getUsers() {
        _isLoading.value = true

        viewModelScope.launch(Dispatchers.IO) {
            ApiConfig.getApiService().getListUsers().enqueue(object: Callback<List<UserResponse>> {
                override fun onResponse(
                    call: Call<List<UserResponse>>,
                    response: Response<List<UserResponse>>
                ) {
                    _isLoading.value = false

                    if (response.isSuccessful) {
                        _users.value = response.body()
                        _isError.value = false
                    } else {
                        Log.d(TAG, "onResponse: ${response.errorBody()}")
                        _isError.value = true
                    }
                }

                override fun onFailure(call: Call<List<UserResponse>>, t: Throwable) {
                    _isLoading.value = false
                    _isError.value = true

                    Log.d(TAG, "onFailure: ${t.message}")
                }
            })
        }
    }

    fun getUsers(username: String) {
        _isLoading.value = true

        viewModelScope.launch(Dispatchers.IO) {
            ApiConfig.getApiService().searchUsers(username).enqueue(object: Callback<SearchResponse> {
                override fun onResponse(
                    call: Call<SearchResponse>,
                    response: Response<SearchResponse>
                ) {
                    _isLoading.value = false

                    if (response.isSuccessful) {
                        _users.value = response.body()?.users
                        _isError.value = false
                    } else {
                        Log.d(TAG, "onResponse: ${response.errorBody()}")
                        _isError.value = true
                    }
                }

                override fun onFailure(call: Call<SearchResponse>, t: Throwable) {
                    _isLoading.value = false
                    _isError.value = true

                    Log.d(TAG, "onFailure: ${t.message}")
                }
            })
        }
    }
    
    companion object {
        const val TAG = "HomeVM"
    }
}