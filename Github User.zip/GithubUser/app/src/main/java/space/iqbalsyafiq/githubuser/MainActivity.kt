package space.iqbalsyafiq.githubuser

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import space.iqbalsyafiq.githubuser.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_DETAILS = "Extra Details"
    }

    private lateinit var binding: ActivityMainBinding
    private var userList = mutableListOf<User>()
    private var searchList = mutableListOf<User>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getDummyData()

        // set view
        with(binding) {
            rvUser.adapter = UserListAdapter(userList as ArrayList<User>)
            etSearch.addTextChangedListener {
                // clear searchList first to avoid duplicate data
                searchList.clear()

                // check for every username in userList that matching with query
                for (user in userList) {
                    if (user.username.contains(it.toString())) {
                        searchList.add(user)
                    }
                }

                // check if the search result is empty
                tvEmptyResult.visibility = if (searchList.isEmpty()) View.VISIBLE else View.GONE

                // set new adapter of recyclerview
                rvUser.adapter = UserListAdapter(searchList as ArrayList<User>)
            }
        }
    }

    fun goToDetails(user: User) {
        Intent(this, DetailActivity::class.java).also {
            it.putExtra(EXTRA_DETAILS, user)
            startActivity(it)
        }
    }

    private fun getDummyData() {
        userList.add(
            User(
                "iqbalsyafiq",
                "Iqbal Shafiq Rozaan",
                "PT DAS",
                "Kediri",
                24,
                30,
                21,
                23,
                "https://images.unsplash.com/photo-1491349174775-aaafddd81942?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80"
            )
        )

        userList.add(
            User(
                "gumilang",
                "Kristoforus Gumilang",
                "XeonCode",
                "Surabaya",
                27,
                33,
                22,
                29,
                "https://images.unsplash.com/photo-1492681290082-e932832941e6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1171&q=80"
            )
        )

        userList.add(
            User(
                "yosia",
                "Yosia",
                "PT DAS",
                "Semarang",
                44,
                33,
                29,
                22,
                "https://images.unsplash.com/photo-1499952127939-9bbf5af6c51c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1176&q=80"
            )
        )

        userList.add(
            User(
                "luqmanahmad",
                "Ahmad Luqman",
                "PT Aku Pintar",
                "Bogor",
                23,
                31,
                31,
                73,
                "https://images.unsplash.com/photo-1494959764136-6be9eb3c261e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            )
        )

        userList.add(
            User(
                "aditsetyo",
                "Adit Setyo",
                "PT Aku Pintar",
                "Probolinggo",
                44,
                90,
                28,
                26,
                "https://images.unsplash.com/photo-1500048993953-d23a436266cf?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1169&q=80"
            )
        )

        userList.add(
            User(
                "antz",
                "Antoni Zamorano",
                "Xeoncode",
                "Surabaya",
                54,
                35,
                51,
                13,
                "https://images.unsplash.com/photo-1644982647531-daff2c7383f3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1074&q=80"
            )
        )

        userList.add(
            User(
                "dewe",
                "David Wibisono",
                "PT DAS",
                "Surabaya",
                26,
                36,
                61,
                63,
                "https://images.unsplash.com/photo-1504593811423-6dd665756598?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            )
        )

        userList.add(
            User(
                "rindarandi",
                "Radny Asnari",
                "PT UNAIR",
                "Magelang",
                21,
                36,
                41,
                24,
                "https://images.unsplash.com/photo-1473830394358-91588751b241?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            )
        )

        userList.add(
            User(
                "junajuned",
                "Dwiki Juna",
                "PT UNAIR",
                "Jakarta Timur",
                34,
                32,
                22,
                13,
                "https://images.unsplash.com/photo-1496302662116-35cc4f36df92?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            )
        )

        userList.add(
            User(
                "rickymaru",
                "Ricky Shikamaru",
                "PT DAS",
                "Semarang",
                74,
                39,
                91,
                29,
                "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80"
            )
        )
    }
}