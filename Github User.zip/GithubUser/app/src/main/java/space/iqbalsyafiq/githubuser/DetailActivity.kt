package space.iqbalsyafiq.githubuser

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import space.iqbalsyafiq.githubuser.MainActivity.Companion.EXTRA_DETAILS
import space.iqbalsyafiq.githubuser.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var user: User

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // get user value from intent
        user = intent.getParcelableExtra(EXTRA_DETAILS)!!

        // set view
        with(binding) {
            tvFullName.text = user.fullName
            tvUsername.text = user.username
            tvCompany.text = user.company
            tvLocation.text = user.location
            tvFollowers.text = user.followers.toString()
            tvFollowing.text = user.following.toString()
            "${user.repository} Repositories".also { tvRepository.text = it }
            "${user.gists} Gists".also { tvGist.text = it }

            // set ivUser with imageDrawable
            Glide.with(this@DetailActivity)
                .asBitmap()
                .circleCrop()
                .load(user.imageDrawable)
                .into(ivUser)

            // FAB back on click listener
            btnBack.setOnClickListener {
                onBackPressed()
            }
        }
    }
}