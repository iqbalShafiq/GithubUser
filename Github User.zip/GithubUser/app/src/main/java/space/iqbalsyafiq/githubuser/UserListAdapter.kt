package space.iqbalsyafiq.githubuser

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.item_user.view.*
import space.iqbalsyafiq.githubuser.databinding.ItemUserBinding

class UserListAdapter(
    private val userList: ArrayList<User>
) : RecyclerView.Adapter<UserListAdapter.ViewHolder>() {
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    private lateinit var binding: ItemUserBinding

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        binding = ItemUserBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )

        return ViewHolder(binding.root)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = userList[position]
        with(holder.itemView) {
            if (user.visible == 0) cardUserItem.visibility = View.GONE
            else cardUserItem.visibility = View.VISIBLE
            tvUsername.text = user.username
            btnDetails.setOnClickListener {
                if (context is MainActivity) {
                    (context as MainActivity).goToDetails(user)
                }
            }

            // set ivUser with imageDrawable
            Glide.with(context)
                .asBitmap()
                .circleCrop()
                .load(user.imageDrawable)
                .into(ivUser)
        }
    }

    override fun getItemCount(): Int = userList.size
}