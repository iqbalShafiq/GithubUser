package space.iqbalsyafiq.githubuser

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class User(
    val username: String,
    val fullName: String,
    val company: String,
    val location: String,
    val repository: Int,
    val gists: Int,
    val followers: Int,
    val following: Int,
    val imageDrawable: String,
    var visible: Int = 1
): Parcelable