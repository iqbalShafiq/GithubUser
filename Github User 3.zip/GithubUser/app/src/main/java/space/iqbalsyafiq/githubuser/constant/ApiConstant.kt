package space.iqbalsyafiq.githubuser.constant

class ApiConstant {
    companion object {
        const val BASE_URL = "https://api.github.com/"
    }
}